//
//  PhotoViewCell.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ٢١ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

class PhotoViewCell: UICollectionViewCell {
    
   static let identifier = "PhotoViewCell"
    var imageUrl:String = ""
    
    @IBOutlet weak var imageCell: UIImageView?
    @IBOutlet weak var activityIndecator: UIActivityIndicatorView!
    
}
