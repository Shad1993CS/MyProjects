//
//  PhotoController+Extension.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ٢٦ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit
import CoreData

extension PhotoViewController:NSFetchedResultsControllerDelegate{
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        insertIndexPaths = [IndexPath]()
        deletedIndexPaths = [IndexPath]()
        updatedIndexPaths = [IndexPath]()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch(type){
        case .insert:
            insertIndexPaths.append(newIndexPath!)
            break
        case .delete:
            deletedIndexPaths.append(newIndexPath!)
            break
        case .move:
            print("Move an item. We don't expect to see this in this app")
            break
        case .update:
            updatedIndexPaths.append(newIndexPath!)
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        collectionView.performBatchUpdates({() -> Void in
            
            for indexPath in self.insertIndexPaths {
                self.collectionView.insertItems(at: [indexPath])
            }
            
            for indexPath in self.deletedIndexPaths {
                self.collectionView.deleteItems(at: [indexPath])
            }
            
            for indexPath in self.updatedIndexPaths {
                self.collectionView.reloadItems(at: [indexPath])
            }
            
        }, completion: nil)
    }
       
    }

extension PhotoViewController : UICollectionViewDataSource,UICollectionViewDelegate {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return fetchResultController?.sections?.count ?? 1
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let sectionInfo = self.fetchResultController?.sections?[section] {
            return sectionInfo.numberOfObjects
        }
        return 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoViewCell.identifier, for: indexPath) as! PhotoViewCell
        cell.imageCell = nil
        cell.activityIndecator.startAnimating()
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let photo = fetchResultController.object(at: indexPath)
        let photoViewCell = cell as! PhotoViewCell
        photoViewCell.imageUrl = photo.imgUrl!
        configImage(using: photoViewCell, photo: photo, collectionView: collectionView, index: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let photoDelete = fetchResultController.object(at: indexPath)
        CoreDataStack.shared().context.delete(photoDelete)
        saveLocation()
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        if collectionView.cellForItem(at: indexPath) == nil {
            return
        }
        let photo = fetchResultController.object(at: indexPath)
        if let imageUrl = photo.imgUrl {
            Client.shared().cancelDownload(imageUrl)
        }
    }
    
    
    private func configImage(using cell: PhotoViewCell, photo: Photo, collectionView: UICollectionView, index: IndexPath) {
        if let imageData = photo.image {
            cell.activityIndecator.stopAnimating()
            cell.imageCell?.image = UIImage(data: Data(referencing: imageData))
        } else {
            if let imageUrl = photo.imgUrl {
                cell.activityIndecator.startAnimating()
                Client.shared().downloadImage(imageUrl: imageUrl) { (data, error) in
                    if let _ = error {
                        self.performUIupdateOnMain {
                            cell.activityIndecator.stopAnimating()
                            self.errorForImageUrl(imageUrl)
                        }
                        return
                    } else if let data = data {
                        self.performUIupdateOnMain {
                            
                            if let currentCell = collectionView.cellForItem(at: index) as? PhotoViewCell {
                                if currentCell.imageUrl == imageUrl {
                                    currentCell.imageCell?.image = UIImage(data: data)
                                    cell.activityIndecator.stopAnimating()
                                }
                            }
                            photo.image = NSData(data: data)
                            DispatchQueue.global(qos: .background).async {
                                self.saveLocation()
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func errorForImageUrl(_ imageUrl: String) {
        if !self.presintigAlert {
            self.showMessage(title: "Error", message: "Error while fetching image for URL: \(imageUrl)") {
                self.presintigAlert = false 
            }
        }
        self.presintigAlert = true
    }
    
    
    
    
}
    
    
    
    
    
    
    
    
    
    
    
    

