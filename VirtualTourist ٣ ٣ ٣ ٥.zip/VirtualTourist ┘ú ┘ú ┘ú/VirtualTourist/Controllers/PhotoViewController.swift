//
//  PhotoViewController.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ٢٤ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotoViewController: UIViewController,MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout:UICollectionViewFlowLayout!
    @IBOutlet weak var collectionButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var labeleIndicator: UILabel!
    
    var selectedIndex : [IndexPath]!
    var insertIndexPaths: [IndexPath]!
    var deletedIndexPaths: [IndexPath]!
    var updatedIndexPaths: [IndexPath]!
    var totalPages: Int? = nil
    
    var presintigAlert = false
    var pin : Pin? = nil
    var fetchResultController: NSFetchedResultsController<Photo>!

    override func viewDidLoad() {
        super.viewDidLoad()

        updatedLayout(size: view.frame.size)
        mapView.delegate = self
        mapView.isZoomEnabled = false
        mapView.isScrollEnabled = false
        updateStatusLabel("")
        guard let pin = pin else {
            return
        }
        showOnTheMap(pin)
        setupFetchResultController(pin: pin)
        if let photos = pin.photos, photos.count == 0 {
            fitchPhotosAPI(pin: pin)
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        updatedLayout(size: size)
    }
    
    @IBAction func deletePhoto(_ sender: Any) {
       
        for Photos in fetchResultController.fetchedObjects!{
            CoreDataStack.shared().context.delete(Photos)
        }
        saveLocation()
        fitchPhotosAPI(pin: pin!)
    }
    
    // Helpers
    private func setupFetchResultController(pin:Pin){
        
        let fitchR = NSFetchRequest<Photo>(entityName: Photo.name)
        fitchR.sortDescriptors = []
        fitchR.predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        
        fetchResultController = NSFetchedResultsController(fetchRequest: fitchR, managedObjectContext: CoreDataStack.shared().context, sectionNameKeyPath: nil, cacheName: nil)
        fetchResultController.delegate = self as? NSFetchedResultsControllerDelegate
        
        var error: NSError?
        do {
            try fetchResultController.performFetch()
        } catch let error1 as NSError {
            error = error1
        }
        if let error = error {
            print("\(#function) Error performing initial fetch: \(error)")
        }
    }
    
    private func showOnTheMap(_ pin: Pin) {
        
        let lat = Double(pin.latitude!)!
        let lon = Double(pin.longitude!)!
        let locCoord = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = locCoord
        
        mapView.removeAnnotations(mapView.annotations)
        mapView.addAnnotation(annotation)
        mapView.setCenter(locCoord, animated: true)
    }
    
    private func loadPhotos(using pin: Pin) -> [Photo]? {
        let predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        var photos: [Photo]?
        do {
            try photos = CoreDataStack.shared().fetchPhotos(predicate, entityName: Photo.name)
        } catch {
            print("\(#function) error:\(error)")
            showMessage(title: "Error", message:"Error while loading Photos from disk: \(error)" )
        }
        return photos
    }
    
    private func fitchPhotosAPI(pin:Pin){
     let latitude = Double(pin.latitude!)!
     let longitude = Double(pin.longitude!)!
     
     activityIndicator.startAnimating()
     self.updateStatusLabel("Fetching Photo's API ...")
        
        Client.shared().searchBy(latitude: latitude, longitude: longitude, totalPages: totalPages) { (photosParsed, error) in
            self.performUIupdateOnMain {
                self.activityIndicator.startAnimating()
                self.labeleIndicator.text = ""
            }
            
            if let photosParsed = photosParsed{
                self.totalPages = photosParsed.photos.pages
                let totalPhotos = photosParsed.photos.photo.count
                print("\(#function)DownLoadin \(totalPhotos) photos")
                self.storePhotos(photosParsed.photos.photo, forPin: pin)
                if  totalPhotos == 0 {
                   self.updateStatusLabel("No Photos Found On this Location 😢")
                }
            }else if let error = error {
                print("\(#function) error:\(error)")
               self.showMessage(title: "Error", message: error.localizedDescription)
               self.updateStatusLabel("Something went wrong , please try again 🧐")
            }
        }
    }
    
    private func storePhotos(_ photos: [PhotoParser], forPin: Pin) {
        func showErrorMessage(msg: String) {
          showMessage(message: msg)
        }
        
        for photo in photos {
            performUIupdateOnMain {
                if let url = photo.url {
                    _ = Photo(title: photo.title, imageUrl: url, forPin: forPin, context: CoreDataStack.shared().context)
                    self.saveLocation()
                }
            }
        }
    }
    
    private func updateStatusLabel(_ text: String) {
        self.performUIupdateOnMain {
            self.labeleIndicator.text = text
        }
    }
    
    private func updatedLayout(size:CGSize){
       let landScape = size.width > size.height
        let space:CGFloat = landScape ? 5:3
        let items:CGFloat = landScape ? 2:3
        
        let dimen = (size.width - (items+1)*space)/items
        flowLayout?.minimumInteritemSpacing = space
        flowLayout?.minimumLineSpacing = space
        flowLayout?.itemSize = CGSize(width: dimen, height: dimen)
        flowLayout?.sectionInset = UIEdgeInsets(top: dimen, left: dimen, bottom: dimen, right: dimen)
    }
    
    func updateBottomB() {
        if selectedIndex.count > 0 {
          collectionButton.setTitle("Remove Selected", for: .normal)
        } else {
           collectionButton.setTitle("New Collection", for: .normal)
        }
    }
}

extension PhotoViewController {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = false
            pinView!.pinTintColor = .red
        } else {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
 
    
}
