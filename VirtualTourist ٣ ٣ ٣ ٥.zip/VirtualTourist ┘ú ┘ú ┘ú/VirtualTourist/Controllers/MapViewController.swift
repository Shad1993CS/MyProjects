//
//  ViewController.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ١٨ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController ,MKMapViewDelegate{
    
    @IBOutlet weak var MapView: MKMapView!
    @IBOutlet weak var footerView: UIView!
    
    var pinAnnotation: MKPointAnnotation? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        MapView.delegate = self
        navigationItem.rightBarButtonItem = editButtonItem
        footerView.isHidden = true
        if let pins = loadAllPins(){
            showPins(pins: pins)
        }
         addLongPressRecognizer()
    }
    
    @IBAction func addGesture(_ sender: UILongPressGestureRecognizer) {
        let loc = sender.location(in: MapView)
        let locC = MapView.convert(loc, toCoordinateFrom: MapView)
        
        if sender.state == .began {
            
            pinAnnotation = MKPointAnnotation()
            pinAnnotation!.coordinate = locC
            
            print("\(#function) Coordinate: \(locC.latitude),\(locC.longitude)")
            
           MapView.addAnnotation(pinAnnotation!)
            
        } else if sender.state == .changed {
            pinAnnotation!.coordinate = locC
        } else if sender.state == .ended {
            
            _ = Pin(
                latitude: String(pinAnnotation!.coordinate.latitude),
                longitude: String(pinAnnotation!.coordinate.longitude),
                context: CoreDataStack.shared().context
            )
            saveLocation()
        }
    }
    
    func addLongPressRecognizer() {
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(addGesture))
        longPressRecognizer.minimumPressDuration = 0.7
        
        MapView.addGestureRecognizer(longPressRecognizer)
    }
    
    
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        footerView.isHidden = !editing
    }
    // Make Navigation
   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is PhotoViewController {
            guard let pin = sender as? Pin else {
                return
            }
            let controller = segue.destination as! PhotoViewController
            controller.pin = pin
        }
    }
    
    // Helpers
    
    private func loadAllPins() -> [Pin]? {
        var pins: [Pin]?
        do {
            try pins = CoreDataStack.shared().fetchAllPins(entityName: Pin.name)
        } catch {
            print("\(#function) error:\(error)")
            showMessage(title: "Error", message: "Error while fetching Pin Location \(error)")
        }
        return pins
    }
    private func loadPin(latitude: String, longitude: String) -> Pin? {
        let predicate = NSPredicate(format: "latitude == %@ AND longitude == %@", latitude, longitude)
        var pin: Pin?
        do {
            try pin = CoreDataStack.shared().fetchPin(predicate, entityName: Pin.name)
        } catch {
            print("\(#function) error:\(error)")
            showMessage(title: "Error", message: "Error while fitching location : \(error)")
        }
        return pin
    }
    
    func showPins(pins:[Pin]){
        for pin in pins where pin.latitude != nil && pin.longitude != nil{
          let annotation = MKPointAnnotation()
          let lat = Double(pin.latitude!)!
          let long = Double(pin.longitude!)!
          annotation.coordinate = CLLocationCoordinate2DMake(lat, long)
            MapView.addAnnotation(annotation)
        }
        MapView.showAnnotations(MapView.annotations, animated: true)
    }
}

extension MapViewController {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reusedId = "Pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reusedId) as? MKPinAnnotationView
        if pinView == nil {
           pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reusedId)
           pinView!.canShowCallout = false
           pinView!.pinTintColor = .red
           pinView!.animatesDrop = true
        }else{
            pinView?.annotation = annotation
        }
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            self.showMessage( message: " No Link Definf")
        }
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard let annotation = view.annotation else {
            return
        }
        
        mapView.deselectAnnotation(annotation, animated: true)
        print("\(#function) lat \(annotation.coordinate.latitude) lon \(annotation.coordinate.longitude)")
        let lat = String(annotation.coordinate.latitude)
        let lon = String(annotation.coordinate.longitude)
        if let pin = loadPin(latitude: lat, longitude: lon) {
            if isEditing {
                mapView.removeAnnotation(annotation)
                CoreDataStack.shared().context.delete(pin)
                saveLocation()
                return
            }
            performSegue(withIdentifier: "showAlbum", sender: pin)
        }
    }
    
    
    }
    
    
    
    
    
    
    
    
    


