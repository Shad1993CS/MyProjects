//
//  PhotoParser.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ٢٢ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import Foundation

struct PhotosParser: Codable {
    let photos: Photos
}

struct Photos: Codable {
    let pages: Int
    let photo: [PhotoParser]
}

struct PhotoParser: Codable {
    
    let url: String?
    let title: String
    
    enum CodingKeys: String, CodingKey {
        case url = "url_n"
        case title
    }
}
