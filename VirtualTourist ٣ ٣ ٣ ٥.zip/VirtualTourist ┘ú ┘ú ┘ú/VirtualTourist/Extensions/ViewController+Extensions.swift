//
//  ViewController+Extensions.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ٢١ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//

import UIKit

extension UIViewController {
    
    var appDelegate : AppDelegate {
      return UIApplication.shared.delegate as! AppDelegate
    }
    
    func saveLocation(){
        
        do{
            try CoreDataStack.shared().saveContext()
            
        }catch {
           showMessage(title: "Eroor", message:"Error while saving Pin location: \(error)")
        }
    }
    
    func showMessage(title:String = "Info" ,message:String,action:(()-> Void)? = nil){
        performUIupdateOnMain {
            let controller = UIAlertController(title: title, message: message, preferredStyle:.alert)
            controller.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) in
                action?()
            }))
             self.present(controller, animated: true)
        }
    }
    
    
    
    func performUIupdateOnMain(update: @escaping() -> Void ){
        DispatchQueue.main.async {
            update()
        }
    }
    
    
    
    
    
    
}
