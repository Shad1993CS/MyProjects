//
//  Photo+CoreDataProperties.swift
//  VirtualTourist
//
//  Created by Shahed Al-shanbati on ٢١ جما١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ Shahed Al-shanbati. All rights reserved.
//
//

import Foundation
import CoreData


extension Photo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Photo> {
        return NSFetchRequest<Photo>(entityName: "Photo")
    }

    @NSManaged public var image: NSData?
    @NSManaged public var imgUrl: String?
    @NSManaged public var title: String?
    @NSManaged public var pin: Pin?

}
